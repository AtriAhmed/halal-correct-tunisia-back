<div>
    <div>
        <strong>Company name :</strong> {{$check->name}}
    </div>
    <div>
        <strong>Name :</strong> {{$check->name}}
    </div>
    <div>
        <strong>Email :</strong> {{$check->email}}
    </div>
    <div>
        <strong>Position :</strong> {{$check->position}}
    </div>
    <div>
        <strong>Question :</strong> {{$check->question}}
    </div>
    <div>
        <strong>Certificate found or used in :</strong> {{$check->question}}
    </div>
    <div>
        <strong>Attached file :</strong> <a href="https://halalcorrect.advanceticsoft.com/{{$check->image}}" download>
            <div style="display:flex;align-items:flex-end;gap:5px;color:blue;">Download file</div>
        </a>
    </div>
</div>