<div>
    <div>
        <strong>Name :</strong> {{ $feedback->name }}
    </div>
    <div>
        <strong>Email :</strong> {{ $feedback->email }}
    </div>
    <div>
        <strong>Feedback :</strong> {{ $feedback->feedback }}
    </div>
</div>