<div>
    <div>
        <strong>Name :</strong> {{ $question->name }}
    </div>
    <div>
        <strong>Email :</strong> {{ $question->email }}
    </div>
    <div>
        <strong>Tel :</strong> {{ $question->tel }}
    </div>
    <div>
        <strong>Question :</strong> {{ $question->question }}
    </div>
</div>