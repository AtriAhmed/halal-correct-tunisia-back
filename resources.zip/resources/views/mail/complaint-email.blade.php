<div>
    <div>
        <strong>Name :</strong> {{ $complaint->name }}
    </div>
    <div>
        <strong>Email :</strong> {{ $complaint->email }}
    </div>
    <div>
        <strong>Complaint :</strong> {{ $complaint->complaint }}
    </div>
</div>