<div>
    <strong>Company Name :</strong> {{$apply->company}}
</div>
<div>
    <strong>Name :</strong> {{$apply->name}}
</div>
<div>
    <strong>Email :</strong> {{$apply->email}}
</div>
<div>
    <strong>Tel :</strong> {{$apply->tel}}
</div>
<div>
    <strong>Head office address :</strong> {{$apply->office_address}}
</div>
<div>
    <strong>Factory address :</strong> {{$apply->factory_address}}
</div>
<div>
    <strong>Explanation :</strong> {{$apply->explanation}}
</div>